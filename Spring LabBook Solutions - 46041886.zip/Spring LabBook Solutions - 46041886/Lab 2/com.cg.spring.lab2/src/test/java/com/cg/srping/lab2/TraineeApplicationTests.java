package com.cg.srping.lab2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraineeApplicationTests {

	@Test
	void contextLoads() {
	}

}

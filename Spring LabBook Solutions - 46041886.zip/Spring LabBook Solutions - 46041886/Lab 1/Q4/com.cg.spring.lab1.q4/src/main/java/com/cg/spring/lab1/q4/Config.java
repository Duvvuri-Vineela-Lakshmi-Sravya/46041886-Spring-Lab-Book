package com.cg.spring.lab1.q4;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

	@Bean
	public Employee emp1()
	{
		return new Employee(100, "Rama", 12345.67);
	}
	
	@Bean
	public Employee emp2()
	{
		return new Employee(101, "kama", 12345.67);
	}
	@Bean
	public Employee emp3()
	{
		return new Employee(102, "jama", 12345.67);
	}
	@Bean
	public Employee emp4()
	{
		return new Employee(103, "Nama", 12345.67);
	}
	@Bean
	public Employee emp5()
	{
		return new Employee(104, "bama", 12345.67);
	}
}

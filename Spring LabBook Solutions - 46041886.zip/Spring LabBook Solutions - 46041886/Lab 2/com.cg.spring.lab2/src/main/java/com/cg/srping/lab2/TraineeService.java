package com.cg.srping.lab2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class TraineeService {
	@Autowired
 	TraineeRepository traineeRepository;
 
 	public List<Trainee> getAllTrainee() 
 	{
       	List<Trainee> trainees = new ArrayList<Trainee>();
       traineeRepository.findAll().forEach(traineer1 -> trainees.add(traineer1));
       	return trainees;
 	}

 	public List<Trainee> getTraineeByName(String traineeName) {
		List<Trainee> trainees=new ArrayList<Trainee>();
		traineeRepository.findAll().forEach(trainee1->trainees.add(trainee1));
		List<Trainee> nameList=new ArrayList<Trainee>();
		for(Trainee t: trainees)
		{
			if(t.getTraineeName().equalsIgnoreCase(traineeName))
				nameList.add(t);	
		}
		return nameList;
	}
 	
 	public void saveTrainee(Trainee trainee) {
       	traineeRepository.save(trainee);
 	}
 

 	public void delete(int traineeId) {
       	traineeRepository.deleteById(traineeId);
 	}
 
 	public void updateTrainee(Trainee trainee) {
       	traineeRepository.save(trainee);
 	}

	public Trainee getTraineeById(int traineeId) {
		return traineeRepository.findById(traineeId).get();
	}

}
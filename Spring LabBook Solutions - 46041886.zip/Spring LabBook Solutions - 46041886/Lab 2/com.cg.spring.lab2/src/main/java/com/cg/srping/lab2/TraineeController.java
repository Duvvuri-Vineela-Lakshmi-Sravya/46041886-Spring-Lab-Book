package com.cg.srping.lab2;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TraineeController 
{
		@Autowired
		TraineeService traineeService;
		
		@PostMapping("/Trainer")
		public int AddTrainee(@RequestBody Trainee trainee)
		{
			traineeService.saveTrainee(trainee);
			return trainee.getTraineeId();
		}
		
		@PutMapping("/Trainer")
		public Trainee Update(@RequestBody Trainee trainee)
		{
			traineeService.updateTrainee(trainee);
			return trainee;
		}
		
		
		@DeleteMapping("/Trainer/{traineeId}")
		public void remove(@PathVariable("traineeId") int traineeId)
		{
			traineeService.delete(traineeId);
		}
		

				
		@GetMapping("/Trainer/{traineeName}")
		public List<Trainee> getTraineeByName(@PathVariable("traineeName") String traineeName)
		{
			return traineeService.getTraineeByName(traineeName);
		}
		
		@GetMapping("/Tra/{traineeId}")
		public Trainee getTraineeById(@PathVariable("traineeId") int traineeId)
		{
			return traineeService.getTraineeById(traineeId);
		}

		
		@GetMapping("/Trainer")
		public List<Trainee> getAllTrainee()
		{
			return traineeService.getAllTrainee();
		}

}
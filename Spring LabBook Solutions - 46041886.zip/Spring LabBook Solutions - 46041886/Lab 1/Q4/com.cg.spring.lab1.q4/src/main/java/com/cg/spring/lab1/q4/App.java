package com.cg.spring.lab1.q4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;



/**
 * Hello world!
 *
 */
@ComponentScan
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new AnnotationConfigApplicationContext(Config.class);

    	Employee emp1=context.getBean("emp1",Employee.class);
    	Employee emp2=context.getBean("emp2",Employee.class);
    	Employee emp3=context.getBean("emp3",Employee.class);
    	Employee emp4=context.getBean("emp4",Employee.class);
    	Employee emp5=context.getBean("emp5",Employee.class);
    	
    	System.out.println("Employee ID: ");
    	Scanner sc=new Scanner(System.in);
    	int val=sc.nextInt();
    	
    	List<Employee> empList=new ArrayList<Employee>();
    	empList.add(emp1);
    	empList.add(emp2);
    	empList.add(emp3);
    	empList.add(emp4);
    	empList.add(emp5);
    	 
    	for(Employee e: empList)
    	{
    		if(e.getId()==val)
    			System.out.println(e);
    	}
    	 
    }
}
